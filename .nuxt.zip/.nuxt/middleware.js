const middleware = {}

middleware['layout-auth'] = require('..\\middleware\\layout-auth.js')
middleware['layout-auth'] = middleware['layout-auth'].default || middleware['layout-auth']

export default middleware
