export const BannerSwiper = () => import('../..\\components\\bannerSwiper.vue' /* webpackChunkName: "components/banner-swiper" */).then(c => wrapFunctional(c.default || c))
export const BigImg = () => import('../..\\components\\bigImg.vue' /* webpackChunkName: "components/big-img" */).then(c => wrapFunctional(c.default || c))
export const FourImagesWithText = () => import('../..\\components\\fourImagesWithText.vue' /* webpackChunkName: "components/four-images-with-text" */).then(c => wrapFunctional(c.default || c))
export const ImgSwiper = () => import('../..\\components\\imgSwiper.vue' /* webpackChunkName: "components/img-swiper" */).then(c => wrapFunctional(c.default || c))
export const News = () => import('../..\\components\\news.vue' /* webpackChunkName: "components/news" */).then(c => wrapFunctional(c.default || c))
export const ProductTest = () => import('../..\\components\\productTest.vue' /* webpackChunkName: "components/product-test" */).then(c => wrapFunctional(c.default || c))
export const Profile = () => import('../..\\components\\profile.vue' /* webpackChunkName: "components/profile" */).then(c => wrapFunctional(c.default || c))
export const ThreeImages = () => import('../..\\components\\threeImages.vue' /* webpackChunkName: "components/three-images" */).then(c => wrapFunctional(c.default || c))
export const TourImgSwiper = () => import('../..\\components\\tourImgSwiper.vue' /* webpackChunkName: "components/tour-img-swiper" */).then(c => wrapFunctional(c.default || c))
export const Videos = () => import('../..\\components\\videos.vue' /* webpackChunkName: "components/videos" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
