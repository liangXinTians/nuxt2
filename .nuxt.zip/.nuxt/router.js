import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _9e9ced8e = () => interopDefault(import('..\\pages\\article\\index.vue' /* webpackChunkName: "pages/article/index" */))
const _0bbf1859 = () => interopDefault(import('..\\pages\\companyProfile\\index.vue' /* webpackChunkName: "pages/companyProfile/index" */))
const _1372c111 = () => interopDefault(import('..\\pages\\contactUs\\index.vue' /* webpackChunkName: "pages/contactUs/index" */))
const _4e2d52a0 = () => interopDefault(import('..\\pages\\index copy.vue' /* webpackChunkName: "pages/index copy" */))
const _02fdf8c0 = () => interopDefault(import('..\\pages\\product\\index.vue' /* webpackChunkName: "pages/product/index" */))
const _3afc06a4 = () => interopDefault(import('..\\pages\\productTest\\index.vue' /* webpackChunkName: "pages/productTest/index" */))
const _499b6c58 = () => interopDefault(import('..\\pages\\video\\index.vue' /* webpackChunkName: "pages/video/index" */))
const _0a7a8a8c = () => interopDefault(import('..\\pages\\companyProfile\\index copy.vue' /* webpackChunkName: "pages/companyProfile/index copy" */))
const _6c2fb923 = () => interopDefault(import('..\\pages\\product\\1\\index.vue' /* webpackChunkName: "pages/product/1/index" */))
const _73e15e82 = () => interopDefault(import('..\\pages\\product\\2\\index.vue' /* webpackChunkName: "pages/product/2/index" */))
const _7b9303e1 = () => interopDefault(import('..\\pages\\product\\3\\index.vue' /* webpackChunkName: "pages/product/3/index" */))
const _f976ad80 = () => interopDefault(import('..\\pages\\product\\4\\index.vue' /* webpackChunkName: "pages/product/4/index" */))
const _245b93a5 = () => interopDefault(import('..\\pages\\product\\index copy.vue' /* webpackChunkName: "pages/product/index copy" */))
const _79667d55 = () => interopDefault(import('..\\pages\\productTest\\1\\index.vue' /* webpackChunkName: "pages/productTest/1/index" */))
const _fdcfba98 = () => interopDefault(import('..\\pages\\productTest\\2\\index.vue' /* webpackChunkName: "pages/productTest/2/index" */))
const _ee6c6fda = () => interopDefault(import('..\\pages\\productTest\\3\\index.vue' /* webpackChunkName: "pages/productTest/3/index" */))
const _df09251c = () => interopDefault(import('..\\pages\\productTest\\4\\index.vue' /* webpackChunkName: "pages/productTest/4/index" */))
const _821bd952 = () => interopDefault(import('..\\pages\\productTest\\index copy.vue' /* webpackChunkName: "pages/productTest/index copy" */))
const _5a420df1 = () => interopDefault(import('..\\pages\\video\\index copy.vue' /* webpackChunkName: "pages/video/index copy" */))
const _46e6d876 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _017dea60 = () => interopDefault(import('..\\pages\\videoDetail\\_.vue' /* webpackChunkName: "pages/videoDetail/_" */))
const _716f6f2a = () => interopDefault(import('..\\pages\\productTestDetail\\_.vue' /* webpackChunkName: "pages/productTestDetail/_" */))
const _ec6efcc8 = () => interopDefault(import('..\\pages\\productDetail\\_.vue' /* webpackChunkName: "pages/productDetail/_" */))
const _71ee04f5 = () => interopDefault(import('..\\pages\\articleDetail\\_.vue' /* webpackChunkName: "pages/articleDetail/_" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/article",
    component: _9e9ced8e,
    name: "article"
  }, {
    path: "/companyProfile",
    component: _0bbf1859,
    name: "companyProfile"
  }, {
    path: "/contactUs",
    component: _1372c111,
    name: "contactUs"
  }, {
    path: "/index%20copy",
    component: _4e2d52a0,
    name: "index copy"
  }, {
    path: "/product",
    component: _02fdf8c0,
    name: "product"
  }, {
    path: "/productTest",
    component: _3afc06a4,
    name: "productTest"
  }, {
    path: "/video",
    component: _499b6c58,
    name: "video"
  }, {
    path: "/companyProfile/index%20copy",
    component: _0a7a8a8c,
    name: "companyProfile-index copy"
  }, {
    path: "/product/1",
    component: _6c2fb923,
    name: "product-1"
  }, {
    path: "/product/2",
    component: _73e15e82,
    name: "product-2"
  }, {
    path: "/product/3",
    component: _7b9303e1,
    name: "product-3"
  }, {
    path: "/product/4",
    component: _f976ad80,
    name: "product-4"
  }, {
    path: "/product/index%20copy",
    component: _245b93a5,
    name: "product-index copy"
  }, {
    path: "/productTest/1",
    component: _79667d55,
    name: "productTest-1"
  }, {
    path: "/productTest/2",
    component: _fdcfba98,
    name: "productTest-2"
  }, {
    path: "/productTest/3",
    component: _ee6c6fda,
    name: "productTest-3"
  }, {
    path: "/productTest/4",
    component: _df09251c,
    name: "productTest-4"
  }, {
    path: "/productTest/index%20copy",
    component: _821bd952,
    name: "productTest-index copy"
  }, {
    path: "/video/index%20copy",
    component: _5a420df1,
    name: "video-index copy"
  }, {
    path: "/",
    component: _46e6d876,
    name: "index"
  }, {
    path: "/videoDetail/*",
    component: _017dea60,
    name: "videoDetail-all"
  }, {
    path: "/productTestDetail/*",
    component: _716f6f2a,
    name: "productTestDetail-all"
  }, {
    path: "/productDetail/*",
    component: _ec6efcc8,
    name: "productDetail-all"
  }, {
    path: "/articleDetail/*",
    component: _71ee04f5,
    name: "articleDetail-all"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
