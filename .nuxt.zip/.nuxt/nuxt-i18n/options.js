import locale6010b66b from '../..\\lang\\en-US.js'

export const Constants = {
  COMPONENT_OPTIONS_KEY: "nuxtI18n",
  STRATEGIES: {"PREFIX":"prefix","PREFIX_EXCEPT_DEFAULT":"prefix_except_default","PREFIX_AND_DEFAULT":"prefix_and_default","NO_PREFIX":"no_prefix"},
}
export const nuxtOptions = {
  isUniversalMode: true,
  trailingSlash: undefined,
}
export const options = {
  vueI18n: {"fallbackLocale":"en","silentTranslationWarn":true},
  vueI18nLoader: true,
  locales: [{"code":"en","name":"English","iso":"en","file":"en-US.js"},{"code":"fr","name":"Français","iso":"fr","file":"fr-FR.js"},{"code":"es","name":"Español","iso":"es","file":"es-ES.js"},{"code":"it","name":"Italiano","iso":"it","file":"it-IT.js"}],
  defaultLocale: "en",
  defaultDirection: "ltr",
  routesNameSeparator: "___",
  defaultLocaleRouteNameSuffix: "default",
  sortRoutes: true,
  strategy: "no_prefix",
  lazy: true,
  langDir: "D:\\ruoyi\\nuxt2\\lang",
  rootRedirect: null,
  detectBrowserLanguage: {"alwaysRedirect":false,"cookieCrossOrigin":false,"cookieDomain":null,"cookieKey":"user_lang","cookieSecure":false,"fallbackLocale":"en","onlyOnNoPrefix":false,"onlyOnRoot":false,"useCookie":true,"redirectOn":"no"},
  differentDomains: false,
  seo: false,
  baseUrl: "https://www.amozici.com/",
  vuex: {"moduleName":"i18n","syncLocale":false,"syncMessages":false,"syncRouteParams":true},
  parsePages: false,
  pages: {},
  skipSettingLocaleOnNavigate: false,
  beforeLanguageSwitch: () => null,
  onBeforeLanguageSwitch: () => {},
  onLanguageSwitched: () => null,
  normalizedLocales: [{"code":"en","name":"English","iso":"en","file":"en-US.js"},{"code":"fr","name":"Français","iso":"fr","file":"fr-FR.js"},{"code":"es","name":"Español","iso":"es","file":"es-ES.js"},{"code":"it","name":"Italiano","iso":"it","file":"it-IT.js"}],
  localeCodes: ["en","fr","es","it"],
}

export const localeMessages = {
  'en-US.js': () => Promise.resolve(locale6010b66b),
  'fr-FR.js': () => import('../..\\lang\\fr-FR.js' /* webpackChunkName: "lang-fr-FR.js" */),
  'es-ES.js': () => import('../..\\lang\\es-ES.js' /* webpackChunkName: "lang-es-ES.js" */),
  'it-IT.js': () => import('../..\\lang\\it-IT.js' /* webpackChunkName: "lang-it-IT.js" */),
}
